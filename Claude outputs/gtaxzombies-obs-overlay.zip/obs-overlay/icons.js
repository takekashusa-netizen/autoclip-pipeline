// GtaxZombies overlay — simple, clean generic platform glyphs
// (not traced brand marks — original shapes in each platform's color)
const GZ_ICONS = {
  twitch: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="4" y="3" width="16" height="13" rx="2" fill="#fff" fill-opacity="0.92"/>
    <rect x="7" y="6" width="2" height="5" fill="#6a2ec9"/>
    <rect x="12" y="6" width="2" height="5" fill="#6a2ec9"/>
    <path d="M8 16v3l3-3h5l4-4V3" stroke="#fff" stroke-opacity="0.92" stroke-width="1.6" fill="none" stroke-linejoin="round"/>
  </svg>`,
  tiktok: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3v10.8a2.6 2.6 0 1 1-2.1-2.55" stroke="#fff" stroke-width="1.8" fill="none" stroke-linecap="round"/>
    <path d="M13 3.2c.5 2.4 2.1 3.9 4.4 4.1" stroke="#25f4ee" stroke-width="1.8" fill="none" stroke-linecap="round"/>
    <path d="M12.5 3.6c.5 2.4 2.1 3.9 4.4 4.1" stroke="#fe2c55" stroke-width="1.8" fill="none" stroke-linecap="round" opacity="0.85"/>
  </svg>`,
  instagram: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="3.5" y="3.5" width="17" height="17" rx="5" stroke="#fff" stroke-width="1.7"/>
    <circle cx="12" cy="12" r="4.2" stroke="#fff" stroke-width="1.7"/>
    <circle cx="17.1" cy="6.9" r="1.15" fill="#fff"/>
  </svg>`,
  youtube: `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="2.5" y="5.5" width="19" height="13" rx="4" fill="#fff" fill-opacity="0.92"/>
    <path d="M10.5 9.2v5.6l5-2.8-5-2.8z" fill="#b3132f"/>
  </svg>`,
};

function gzInjectIcons(root = document) {
  root.querySelectorAll('[data-gz-icon]').forEach((el) => {
    const key = el.getAttribute('data-gz-icon');
    if (GZ_ICONS[key]) el.innerHTML = GZ_ICONS[key];
  });
}
