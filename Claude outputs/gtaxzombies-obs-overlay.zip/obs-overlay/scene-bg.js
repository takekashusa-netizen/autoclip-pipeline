// GtaxZombies overlay — shared full-screen 3D background for scene screens
// (Starting Soon / BRB / Stream Ended). Not used on the main gameplay
// overlay, which stays mostly transparent on purpose.
function gzInitSceneBackground(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!window.THREE || !canvas) return;

  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  renderer.setSize(1920, 1080, false);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(50, 1920 / 1080, 0.1, 200);
  camera.position.z = 30;

  // drifting particle field — kept within the camera frustum (z < 20 so
  // none sit behind/at the camera, which was silently clipping half of them)
  const particleCount = 320;
  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 70;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 40;
    positions[i * 3 + 2] = Math.random() * -40;
  }
  const pGeo = new THREE.BufferGeometry();
  pGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const pMat = new THREE.PointsMaterial({ color: 0x9be9ff, size: 0.9, transparent: true, opacity: 0.95, sizeAttenuation: true });
  const particles = new THREE.Points(pGeo, pMat);
  scene.add(particles);

  // large slow-rotating wireframe shapes for depth — brighter + closer
  // to camera so they actually read on screen instead of blending into bg
  const shapes = [];
  const specs = [
    { r: 8, color: 0xa855f7, x: -19, y: 6, z: -14, op: 0.85 },
    { r: 6, color: 0x4de3ff, x: 20, y: -8, z: -10, op: 0.75 },
    { r: 5, color: 0xd6a8ff, x: 13, y: 12, z: -17, op: 0.65 },
  ];
  specs.forEach((s) => {
    const geo = new THREE.IcosahedronGeometry(s.r, 0);
    const mat = new THREE.MeshBasicMaterial({ color: s.color, wireframe: true, transparent: true, opacity: s.op });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(s.x, s.y, s.z);
    scene.add(mesh);
    shapes.push(mesh);
  });

  function animate() {
    requestAnimationFrame(animate);
    particles.rotation.y += 0.0006;
    shapes.forEach((m, i) => {
      m.rotation.x += 0.0018 + i * 0.0004;
      m.rotation.y += 0.0022 + i * 0.0003;
    });
    renderer.render(scene, camera);
  }
  animate();
}
